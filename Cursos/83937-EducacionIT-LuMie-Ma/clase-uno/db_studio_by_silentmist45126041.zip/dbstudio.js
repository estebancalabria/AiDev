class DBStudio {
    constructor() {
        this.currentTab = 'estructura';
        this.currentTable = null;
        this.dbName = 'MiBaseDatos';
        this.init();
    }
    
    init() {
        this.loadDatabase();
        this.setupEventListeners();
        this.updateStatus('Listo');
    }
    
    setupEventListeners() {
        document.getElementById('queryEditor').addEventListener('keydown', (e) => {
            if (e.ctrlKey && e.key === 'Enter') {
                e.preventDefault();
                this.executeQuery();
            }
        });
    }
    
    loadDatabase() {
        try {
            const tables = this.getStoredTables();
            this.renderDatabaseTree(tables);
        } catch (error) {
            this.showError('Error al cargar la base de datos: ' + error.message);
        }
    }
    
    getStoredTables() {
        const stored = localStorage.getItem('dbstudio_tables');
        return stored ? JSON.parse(stored) : {};
    }
    
    saveTables(tables) {
        localStorage.setItem('dbstudio_tables', JSON.stringify(tables));
    }
    
    renderDatabaseTree(tables) {
        const treeEl = document.getElementById('dbTree');
        const tableNames = Object.keys(tables);
        
        if (tableNames.length === 0) {
            treeEl.innerHTML = '<div class="empty-state">No hay tablas en la base de datos</div>';
            return;
        }
        
        treeEl.innerHTML = `
            <div class="tree-item" onclick="dbStudio.selectTable(null)">
                <span>📁 Tablas (${tableNames.length})</span>
            </div>
            ${tableNames.map(tableName => `
                <div class="tree-item" onclick="dbStudio.selectTable('${tableName}')" style="padding-left: 32px;">
                    <span>📋 ${tableName}</span>
                </div>
            `).join('')}
        `;
    }
    
    selectTable(tableName) {
        this.currentTable = tableName;
        this.updateTableSelection();
        
        if (this.currentTab === 'datos' && tableName) {
            this.showTableData(tableName);
        }
    }
    
    updateTableSelection() {
        const items = document.querySelectorAll('.tree-item');
        items.forEach(item => item.classList.remove('active'));
        
        if (this.currentTable) {
            const selectedItem = Array.from(items).find(item => 
                item.textContent.includes(this.currentTable)
            );
            if (selectedItem) selectedItem.classList.add('active');
        }
    }
    
    switchTab(tab) {
        this.currentTab = tab;
        
        document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('[id$="-view"]').forEach(v => v.style.display = 'none');
        
        event.target.classList.add('active');
        document.getElementById(tab + '-view').style.display = 'block';
        
        if (tab === 'datos' && this.currentTable) {
            this.showTableData(this.currentTable);
        }
    }
    
    showTableData(tableName) {
        const tables = this.getStoredTables();
        const table = tables[tableName];
        
        if (!table || !table.data || table.data.length === 0) {
            document.getElementById('dataResults').innerHTML = 
                '<div class="empty-state">La tabla está vacía</div>';
            this.updateRecordCount(0);
            return;
        }
        
        const headers = Object.keys(table.data[0]);
        const html = `
            <table class="results-table">
                <thead>
                    <tr>
                        ${headers.map(h => `<th>${h}</th>`).join('')}
                    </tr>
                </thead>
                <tbody>
                    ${table.data.map(row => `
                        <tr>
                            ${headers.map(h => `<td>${row[h] || ''}</td>`).join('')}
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
        
        document.getElementById('dataResults').innerHTML = html;
        this.updateRecordCount(table.data.length);
    }
    
    newQuery() {
        this.switchTab('consulta');
        document.getElementById('queryEditor').value = '';
        document.getElementById('queryResults').innerHTML = 
            '<div class="empty-state">Los resultados aparecerán aquí</div>';
    }
    
    executeQuery() {
        const query = document.getElementById('queryEditor').value.trim();
        if (!query) return;
        
        try {
            const result = this.parseAndExecuteQuery(query);
            this.displayQueryResults(result);
            this.updateStatus('Consulta ejecutada exitosamente');
        } catch (error) {
            this.showError('Error en la consulta: ' + error.message);
        }
    }
    
    parseAndExecuteQuery(query) {
        const upperQuery = query.toUpperCase();
        const tables = this.getStoredTables();
        
        if (upperQuery.startsWith('SELECT')) {
            return this.executeSelect(query, tables);
        } else if (upperQuery.startsWith('INSERT')) {
            return this.executeInsert(query, tables);
        } else if (upperQuery.startsWith('UPDATE')) {
            return this.executeUpdate(query, tables);
        } else if (upperQuery.startsWith('DELETE')) {
            return this.executeDelete(query, tables);
        } else if (upperQuery.startsWith('CREATE TABLE')) {
            return this.executeCreateTable(query, tables);
        } else if (upperQuery.startsWith('DROP TABLE')) {
            return this.executeDropTable(query, tables);
        } else {
            throw new Error('Tipo de consulta no soportado');
        }
    }
    
    executeSelect(query, tables) {
        const match = query.match(/SELECT\s+(.+)\s+FROM\s+(\w+)/i);
        if (!match) throw new Error('Sintaxis SELECT inválida');
        
        const [, columns, tableName] = match;
        const table = tables[tableName];
        
        if (!table) throw new Error(`Tabla '${tableName}' no existe`);
        
        let data = table.data || [];
        
        const whereMatch = query.match(/WHERE\s+(.+)/i);
        if (whereMatch) {
            data = this.applyWhere(data, whereMatch[1]);
        }
        
        const limitMatch = query.match(/LIMIT\s+(\d+)/i);
        if (limitMatch) {
            data = data.slice(0, parseInt(limitMatch[1]));
        }
        
        return {
            type: 'select',
            data: data,
            columns: columns === '*' ? Object.keys(data[0] || {}) : columns.split(',').map(c => c.trim())
        };
    }
    
    executeInsert(query, tables) {
        const match = query.match(/INSERT\s+INTO\s+(\w+)\s+\(([^)]+)\)\s+VALUES\s+\(([^)]+)\)/i);
        if (!match) throw new Error('Sintaxis INSERT inválida');
        
        const [, tableName, columns, values] = match;
        const table = tables[tableName];
        
        if (!table) throw new Error(`Tabla '${tableName}' no existe`);
        
        const columnArray = columns.split(',').map(c => c.trim());
        const valueArray = values.split(',').map(v => this.parseValue(v.trim()));
        
        const newRow = {};
        columnArray.forEach((col, i) => {
            newRow[col] = valueArray[i];
        });
        
        if (!table.data) table.data = [];
        table.data.push(newRow);
        
        this.saveTables(tables);
        return { type: 'insert', affectedRows: 1 };
    }
    
    executeUpdate(query, tables) {
        const match = query.match(/UPDATE\s+(\w+)\s+SET\s+(.+?)(?:\s+WHERE\s+(.+))?$/i);
        if (!match) throw new Error('Sintaxis UPDATE inválida');
        
        const [, tableName, setClause, whereClause] = match;
        const table = tables[tableName];
        
        if (!table) throw new Error(`Tabla '${tableName}' no existe`);
        
        const setPairs = setClause.split(',').map(pair => {
            const [col, val] = pair.split('=');
            return [col.trim(), this.parseValue(val.trim())];
        });
        
        let data = table.data || [];
        let affectedRows = 0;
        
        if (whereClause) {
            data = data.map(row => {
                if (this.evaluateWhere(row, whereClause)) {
                    setPairs.forEach(([col, val]) => {
                        row[col] = val;
                    });
                    affectedRows++;
                    return row;
                }
                return row;
            });
        } else {
            data = data.map(row => {
                setPairs.forEach(([col, val]) => {
                    row[col] = val;
                });
                affectedRows++;
                return row;
            });
        }
        
        table.data = data;
        this.saveTables(tables);
        return { type: 'update', affectedRows };
    }
    
    executeDelete(query, tables) {
        const match = query.match(/DELETE\s+FROM\s+(\w+)(?:\s+WHERE\s+(.+))?$/i);
        if (!match) throw new Error('Sintaxis DELETE inválida');
        
        const [, tableName, whereClause] = match;
        const table = tables[tableName];
        
        if (!table) throw new Error(`Tabla '${tableName}' no existe`);
        
        let data = table.data || [];
        let affectedRows = 0;
        
        if (whereClause) {
            const originalLength = data.length;
            data = data.filter(row => !this.evaluateWhere(row, whereClause));
            affectedRows = originalLength - data.length;
        } else {
            affectedRows = data.length;
            data = [];
        }
        
        table.data = data;
        this.saveTables(tables);
        return { type: 'delete', affectedRows };
    }
    
    executeCreateTable(query, tables) {
        const match = query.match(/CREATE\s+TABLE\s+(\w+)/i);
        if (!match) throw new Error('Sintaxis CREATE TABLE inválida');
        
        const tableName = match[1];
        
        if (tables[tableName]) {
            throw new Error(`La tabla '${tableName}' ya existe`);
        }
        
        tables[tableName] = {
            name: tableName,
            columns: [],
            data: []
        };
        
        this.saveTables(tables);
        this.loadDatabase();
        return { type: 'create', message: `Tabla '${tableName}' creada exitosamente` };
    }
    
    executeDropTable(query, tables) {
        const match = query.match(/DROP\s+TABLE\s+(\w+)/i);
        if (!match) throw new Error('Sintaxis DROP TABLE inválida');
        
        const tableName = match[1];
        
        if (!tables[tableName]) {
            throw new Error(`La tabla '${tableName}' no existe`);
        }
        
        delete tables[tableName];
        this.saveTables(tables);
        this.loadDatabase();
        return { type: 'drop', message: `Tabla '${tableName}' eliminada exitosamente` };
    }
    
    applyWhere(data, whereClause) {
        return data.filter(row => this.evaluateWhere(row, whereClause));
    }
    
    evaluateWhere(row, whereClause) {
        const conditions = whereClause.split(/AND|OR/i);
        return conditions.some(condition => {
            const [column, operator, value] = condition.trim().split(/\s+/);
            const rowValue = row[column];
            const compareValue = this.parseValue(value);
            
            switch (operator) {
                case '=': return rowValue == compareValue;
                case '!=': return rowValue != compareValue;
                case '>': return rowValue > compareValue;
                case '<': return rowValue < compareValue;
                case '>=': return rowValue >= compareValue;
                case '<=': return rowValue <= compareValue;
                default: return false;
            }
        });
    }
    
    parseValue(value) {
        if (value.startsWith("'") && value.endsWith("'")) {
            return value.slice(1, -1);
        }
        if (value === 'NULL') return null;
        if (!isNaN(value)) return Number(value);
        return value;
    }
    
    displayQueryResults(result) {
        const resultsEl = document.getElementById('queryResults');
        
        if (result.type === 'select') {
            if (!result.data || result.data.length === 0) {
                resultsEl.innerHTML = '<div class="empty-state">La consulta no devolvió resultados</div>';
                this.updateRecordCount(0);
                return;
            }
            
            const headers = result.columns;
            const html = `
                <table class="results-table">
                    <thead>
                        <tr>
                            ${headers.map(h => `<th>${h}</th>`).join('')}
                        </tr>
                    </thead>
                    <tbody>
                        ${result.data.map(row => `
                            <tr>
                                ${headers.map(h => `<td>${row[h] || ''}</td>`).join('')}
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            `;
            
            resultsEl.innerHTML = html;
            this.updateRecordCount(result.data.length);
        } else {
            const message = result.message || 
                `${result.type.toUpperCase()} ejecutado exitosamente. ${result.affectedRows || 0} filas afectadas.`;
            resultsEl.innerHTML = `<div class="success-message">${message}</div>`;
        }
    }
    
    createTable() {
        document.getElementById('modalTitle').textContent = 'Nueva Tabla';
        document.getElementById('tableName').value = '';
        document.getElementById('columnsContainer').innerHTML = `
            <div class="form-group">
                <label>Columna 1:</label>
                <input type="text" placeholder="Nombre columna" class="column-name">
                <select class="column-type">
                    <option value="TEXT">TEXTO</option>
                    <option value="INTEGER">NUMERO</option>
                    <option value="REAL">DECIMAL</option>
                </select>
            </div>
        `;
        document.getElementById('tableModal').classList.add('show');
    }
    
    addColumn() {
        const container = document.getElementById('columnsContainer');
        const columnCount = container.querySelectorAll('.form-group').length;
        
        const newColumn = document.createElement('div');
        newColumn.className = 'form-group';
        newColumn.innerHTML = `
            <label>Columna ${columnCount + 1}:</label>
            <input type="text" placeholder="Nombre columna" class="column-name">
            <select class="column-type">
                <option value="TEXT">TEXTO</option>
                <option value="INTEGER">NUMERO</option>
                <option value="REAL">DECIMAL</option>
            </select>
        `;
        
        container.appendChild(newColumn);
    }
    
    saveTable() {
        const tableName = document.getElementById('tableName').value.trim();
        if (!tableName) {
            alert('Por favor ingresa un nombre de tabla');
            return;
        }
        
        const tables = this.getStoredTables();
        if (tables[tableName]) {
            alert('La tabla ya existe');
            return;
        }
        
        const columnNames = Array.from(document.querySelectorAll('.column-name'))
            .map(input => input.value.trim())
            .filter(name => name);
        
        if (columnNames.length === 0) {
            alert('Por favor ingresa al menos una columna');
            return;
        }
        
        tables[tableName] = {
            name: tableName,
            columns: columnNames.map((name, i) => ({
                name: name,
                type: document.querySelectorAll('.column-type')[i].value
            })),
            data: []
        };
        
        this.saveTables(tables);
        this.loadDatabase();
        this.closeModal();
        this.updateStatus(`Tabla '${tableName}' creada exitosamente`);
    }
    
    dropTable() {
        if (!this.currentTable) {
            alert('Por favor selecciona una tabla para eliminar');
            return;
        }
        
        if (confirm(`¿Estás seguro de que quieres eliminar la tabla '${this.currentTable}'? Esta acción no se puede deshacer.`)) {
            const tables = this.getStoredTables();
            delete tables[this.currentTable];
            this.saveTables(tables);
            this.currentTable = null;
            this.loadDatabase();
            this.updateStatus(`Tabla eliminada exitosamente`);
        }
    }
    
    refreshDatabase() {
        this.loadDatabase();
        this.updateStatus('Base de datos actualizada');
    }
    
    closeModal() {
        document.getElementById('tableModal').classList.remove('show');
    }
    
    updateStatus(message) {
        document.getElementById('statusText').textContent = message;
        setTimeout(() => {
            document.getElementById('statusText').textContent = 'Listo';
        }, 3000);
    }
    
    updateRecordCount(count) {
        document.getElementById('recordCount').textContent = `${count} registros`;
    }
    
    showError(message) {
        const resultsEl = document.getElementById('queryResults');
        resultsEl.innerHTML = `<div class="error-message">${message}</div>`;
        this.updateStatus('Error en la consulta');
    }
}

window.dbStudio = new DBStudio();

